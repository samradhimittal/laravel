<aside class="main-sidebar">
    <section class="sidebar">
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">Management Panel</li>
            <li class="<?php echo e($nav == 'dashboard' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('for_moderator', Auth::user())): ?>
                <li class="<?php echo e($nav == 'users' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users.index')); ?>"><i class="fa fa-user"></i> <span>Users</span></a></li>

                <li class="<?php echo e($nav == 'import' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.employees.index')); ?>"><i class="fa fa-user"></i> <span>Employee info</span></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('for_administrator', Auth::user())): ?>
            <?php endif; ?>
        </ul>
    </section>
</aside>
<?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/partials/aside.blade.php ENDPATH**/ ?>