<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('admin.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('custom_styles'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.partials.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        <?php echo $__env->make('admin.partials.flashes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Dashboard <small><?php echo e($nav); ?></small>
                    <?php if($nav != 'dashboard' && $action != 'create' && $action != 'no_add'): ?>
                        <a class="btn btn-success" href="<?php echo e(route('admin.' . $nav . '.create')); ?>">
                            <i class="fa fa-plus"></i> Add
                        </a>
                    <?php endif; ?>
                </h1>
            </section>

            <!-- Main content -->
            <section class="content">

                <?php echo $__env->yieldContent('content'); ?>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

    
</div>

<?php echo $__env->make('admin.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('custom_scripts'); ?>

</body>
</html>
<?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>