<?php $__env->startSection('content'); ?>
    <p>Welcome to main page of <?php echo e(config('app.name')); ?> Admin Panel!</p>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/pages/dashboard.blade.php ENDPATH**/ ?>