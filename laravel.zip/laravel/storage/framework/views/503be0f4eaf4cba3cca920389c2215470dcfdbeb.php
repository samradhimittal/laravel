<?php $__env->startPush('custom_styles'); ?>
    <?php echo $__env->make('admin.components.switcher2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <table id="yajra_datatable" class="table table-bordered">
        <thead>
        <tr>
            <th>Emp Id</th>
            <th>Basc Salary</th>
            <th>overtime</th>
            <th>Total Salary</th>
            
        </tr>
        </thead>
    </table>

    <?php echo $__env->make('admin.components.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_scripts'); ?>
    <script type="text/javascript">
        function delete_action(item_id){
            $('#item_id').val(item_id);
        }
        function initDataTable() {
            var YajraDataTable = $('#yajra_datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('admin.employees.ajax')); ?>",
                "columns":[
                    {
                        "data": "emp_id",
                        "name": "emp_id",
                    },
                    {
                        "data": "basic salary",
                        "name": "basic_salary",
                    },
                    {
                        "data": "overtime",
                        "name": "address",
                    },
                    {
                        "data": "total salary",
                        "name": "is_ative",
                    },
                    
                ],
                "autoWidth": false,
                // "drawCallback": function(settings, json) {
                //     // callback function that is called every time DataTables performs a draw
                //     var items_array = settings.json.data;
                //     for (var i = 0; i < items_array.length; i++) {
                //         initSwitcher(items_array[i].status, items_array[i].id, false);
                //     }
                // },
                'columnDefs': [
                    { // options
                        'targets': -4,
                        'defaultContent': '-',
                        'searchable': false,
                        'orderable': false,
                        'width': '10%',
                        'className': 'dt-body-center',
                        'render': function (data, type, full_row, meta){
                            return full_row.emp_id;
                        }

                    },
                    { // options
                        'targets': -3,
                        'defaultContent': '-',
                        'searchable': false,
                        'orderable': false,
                        'width': '10%',
                        'className': 'dt-body-center',
                        'render': function (data, type, full_row, meta){
                            return full_row.basic_salary;
                        }

                    },                    
                    { // address
                        'targets': -2,
                        'defaultContent': '-',
                        'searchable': false,
                        'orderable': false,
                        'width': '10%',
                        'className': 'dt-body-center',
                        'render': function (data, type, full_row, meta){
                            return full_row.overtime;
                        }
                    },
                    { // address
                        'targets': -1,
                        'defaultContent': '-',
                        'searchable': false,
                        'orderable': false,
                        'width': '10%',
                        'className': 'dt-body-center',
                        'render': function (data, type, full_row, meta){
                            return full_row.total_salary;
                        }
                    },
                ],
                // 'order': [1, 'asc'], // Order on init. Number is the column, starting at 0
            });
            return YajraDataTable;
        }
        function change_status_action(item_id){
            // e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('admin.users.change_status')); ?>",
                data: {
                    'item_id': item_id,
                    '_token': "<?php echo e(csrf_token()); ?>"
                },
                type: "POST",
                success: function (response) {
                   
                    if(response.success){
                        alert(response.message);
                    }else{
                        console.log(response.message);
                    }
                }
            });
        }

        $(document).ready(function() {

            var YajraDataTable = initDataTable();

            $('#delete_action').on('click', function (e) {
                e.preventDefault();
                $.ajax({
                    url: "<?php echo e(route('admin.users.delete')); ?>",
                    data: {
                        'item_id': $('#item_id').val(),
                        '_token': "<?php echo e(csrf_token()); ?>"
                    },
                    type: "POST",
                    success: function (response) {
                        $('#modal_delete').modal('hide');
                        // var data = JSON.parse(response);
                        if (response.success) {
                            YajraDataTable.ajax.reload(null, false);
                        }else{
                            console.log(response.message);
                        }
                    }
                })
            });

            $('#modal_delete').on('hidden.bs.modal', function () {
                $('#item_id').val(0);
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/pages/employees/index.blade.php ENDPATH**/ ?>