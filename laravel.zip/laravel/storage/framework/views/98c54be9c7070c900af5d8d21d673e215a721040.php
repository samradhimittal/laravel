<?php $__env->startSection('content'); ?>
    <p>User id = <?php echo e($item->id); ?></p>
    <p>User address = <?php echo e($item->address); ?></p>
    <p>User name = <?php echo e($item->name); ?></p>
    <p>User email = <?php echo e($item->email); ?></p>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/pages/users/show.blade.php ENDPATH**/ ?>