<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b><?php echo e(config('app.name')); ?></b>
    </div>
    <strong>Copyright &copy; <?php echo e('2019' . (date('Y') == 2019 ? '' : '-' . date('Y'))); ?></strong> All rights reserved.
</footer><?php /**PATH /var/www/html/laravel-multiauth/resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>