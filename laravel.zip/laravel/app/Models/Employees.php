<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employees extends Model
{

    protected $table = 'employees';

    protected $appends = ['overtime'];
    
    public function getOvertimeAttribute()
    {
        if($this->total_hours>0){

            return ($this->per_day_salary/$this->total_hours)*($this->total_hours-8);
        }
        else{
            return 0;
        }
    }
}