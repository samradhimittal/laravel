<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Employees;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Yajra\DataTables\DataTables;
use DB;

class EmployeeController extends Controller
{

    private $weekday = array(2,3,4,5,6);

    public function __construct()
    {
        $this->middleware('auth:admin');

        View::share('action', 'no_add');
        View::share('nav', 'users');
    }

    public function index()
    { 
       
        
        return view('admin.pages.employees.index');
    }

    public function ajax()
    {
        $employees = Employees::select('emp_id','basic_salary')                          
                    ->selectRaw('sum(per_day_salary) as total_salary')
                    ->where('date','LIKE','Feb %, 2020')
                    ->whereIn('weekday',$this->weekday)                  
                    ->groupBy('emp_id')
                    ->get();

        return DataTables::of($employees)->make(true);
        
    }

    public function show($item_id)
    {
        $item = User::find($item_id);
        if(empty($item)){
            return redirect()->route('admin.dashboard');
        }

        return view('admin.pages.users.show', [
            'item' => $item,
        ]);
    }

    
}
