<?php
Route::group([
    'namespace' => 'Auth',
], function () {
    // Authentication Routes...
    Route::get('login', 'LoginController@showLoginForm')->name('login_page');
    Route::post('login', 'LoginController@login')->name('login');
    Route::post('logout', 'LoginController@logout')->name('logout');
});

Route::group([
    'middleware' => [
        'auth:admin',
    ],
], function () {

    // for all admins
    Route::get('/', 'AdminController@index')->name('dashboard');
    Route::get('home', 'AdminController@index')->name('dashboard');
    Route::get('dashboard', 'AdminController@index')->name('dashboard');


    // for administrator
    Route::group(['middleware' => ['role:administrator']], function () {

        // users
        Route::group(['prefix' => 'employees', 'as' => 'employees.',], function () {
            Route::get('all', 'EmployeeController@index')->name('index');
            Route::get('ajax', 'EmployeeController@ajax')->name('ajax');           
        });
    
        // users
        Route::group(['prefix' => 'users', 'as' => 'users.',], function () {
            Route::get('all', 'UserController@index')->name('index');
            Route::get('ajax', 'UserController@ajax')->name('ajax');
            Route::get('show/{id}', 'UserController@show'); // ->where('id', '[0-9]+');
            Route::post('change_status', 'UserController@change_status')->name('change_status');
            Route::post('delete', 'UserController@delete')->name('delete');
        });
    });

    // for moderators
    Route::group([
        'middleware' => ['role:administrator|moderator'],
    ], function () {
        // users
        Route::group(['prefix' => 'users', 'as' => 'users.',], function () {
            Route::get('all', 'UserController@index')->name('index');
        });
    });

    

});

