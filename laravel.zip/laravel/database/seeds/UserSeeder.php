<?php

use App\Models\User;
use Illuminate\Database\Seeder;
use Faker\Factory;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    protected $seed_items = [];

    public function create_dev_users()
    {
        User::create([
            'name' => config('project.seed.dev_name'),
            'email' => config('project.seed.dev_email'),
            'is_active' => User::ACTIVE,
            'password' => bcrypt(config('project.seed.dev_password')),
        ]);
    }

    public function run()
    {
        $this->create_dev_users();

        // necessary definitions
        $faker = Factory::create('en_US');
        $date = Carbon::now();
        
        $user_statuses = [
            User::ACTIVE,
            User::NOT_ACTIVE,
        ];

        // add candidate users to the $seed_items
        for ($i = 0; $i < config('project.seed.users_count'); $i++) {
            $status = $faker->randomElement($user_statuses);
           
        }

        // create users via importing $seed_items to 'users' table
        DB::table('users')->insert($this->seed_items);
    }    
}
