<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>{{ config('app.name') }}</b>
    </div>
    <strong>Copyright &copy; {{ '2019' . (date('Y') == 2019 ? '' : '-' . date('Y')) }}</strong> All rights reserved.
</footer>