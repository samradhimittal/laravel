@extends('admin.layouts.app')


@section('content')
    <p>User id = {{ $item->id  }}</p>
    <p>User address = {{ $item->address  }}</p>
    <p>User name = {{ $item->name  }}</p>
    <p>User email = {{ $item->email  }}</p>
@endsection

