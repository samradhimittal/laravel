@extends('admin.layouts.app')

{{--@push('custom_styles')--}}
{{--@endpush--}}

@section('content')
    <p>Welcome to main page of {{ config('app.name') }} Admin Panel!</p>
@endsection

{{--@push('custom_scripts)--}}
{{--@endpush--}}
